
import sys
import os
import subprocess
import ConfigParser
import time
import random
import commands
import socket
import requests
import json
from subtools import SubTools
from resource_management import *
from resource_management.core.resources.system import File, Execute, Directory
from resource_management.libraries.functions.format import format
from resource_management.core.resources.service import Service
from resource_management.core.exceptions import ComponentIsNotRunning
from resource_management.core import shell
from resource_management.libraries.script.script import Script
from ambari_agent import AmbariConfig
from BeautifulSoup import BeautifulStoneSoup as Soup



sbtls = SubTools()

confInfo = sbtls.sp_open("curl -u admin:admin -X GET  http://192.168.1.194:8080/api/v1/clusters/bigcluster?fields=Clusters/desired_configs")

j = json.loads(confInfo[0])
desiredConf = j['Clusters']['desired_configs']
targetSites = ('mapred-site','yarn-site','core-site')
# targetSites = ('mapred-site')
for targetSite in targetSites:
  print targetSite
  print desiredConf[targetSite]['tag']
  print desiredConf

  versionNum = desiredConf[targetSite]['tag'].split('version')[1]

  nextVersionNum = str(int(versionNum)+1)

  targetConf = sbtls.sp_open('curl -u admin:admin -H "X-Requested-By: ambari" -X GET "http://192.168.1.194:8080/api/v1/clusters/bigcluster/configurations?type='+targetSite+'&tag='+desiredConf[targetSite]['tag']+'"')

  targetJson = json.loads(targetConf[0])

  prop = targetJson['items'][0]['properties']
  # print prop
  if targetSite == 'core-site':
    prop['fs.lustrefs.impl'] = u"org.apache.hadoop.fs.lustrefs.LustreFileSystem"
    prop['fs.AbstractFileSystem.lustrefs.impl'] = u"org.apache.hadoop.fs.local.LustreFs"
    prop['fs.defaultFS'] = u"lustrefs:///"
    prop['fs.lustrefs.mount'] = u"/mnt/lustre/hadoop"
    prop['hadoop.tmp.dir'] = u"/tmp3/hadoop-${user.name}"

  elif targetSite == 'yarn-site':
    prop['yarn.nodemanager.container-executor.class'] = u"org.apache.hadoop.yarn.server.nodemanager.LinuxContainerExecutor"
    prop['yarn.nodemanager.linux-container-executor.nonsecure-mode.local-user'] = u"yarn"
    prop['yarn.nodemanager.linux-container-executor.nonsecure-mode.limit-users'] = u"false"
    prop['yarn.nodemanager.local-dirs'] = u"/tmp3/yarn/local"
    prop['yarn.nodemanager.log-dirs'] = u"/tmp3/yarn/log"
    prop['yarn.timeline-service.leveldb-state-store.path'] = u"/tmp3/yarn/timeline"
    prop['yarn.timeline-service.leveldb-timeline-store.path'] = u"/tmp3/yarn/timeline"

  elif targetSite == 'mapred-site':
    prop['yarn.app.mapreduce.am.staging-dir'] = u"/tmp3/hadoop-${user.name}/staging"

    # print json.dumps(prop)

  reqHead = 'curl -u admin:admin -H "X-Requested-By: ambari" -X PUT -d '
  reqBody = '[{"Clusters":{"desired_config":[{"type":"'+targetSite+'","tag":"'+nextVersionNum+'","service_config_version_note":"New config version"}]}}]'
  reqTail = ' "http://192.168.1.194:8080/api/v1/clusters/bigcluster"'

  body = json.loads(reqBody)
  body[0]['Clusters']['desired_config'][0][u'properties']=prop
  reqBody = json.dumps(body)

  # 변경 요청
  # print sbtls.sp_open(reqHead+"'"+reqBody+"'"+reqTail)
