import subprocess

class SubTools:
    def __init__(self):
        pass
    def xmlFileWriter(self,fileName,data):
        f = open(fileName, 'w')
        f.write(data)
        f.close()

    def xmlChanger(self,baseNodes, updNodes):
        for uNode in updNodes.findAll('property'):
            uName = uNode.find('name').string
            uValue = uNode.find('value').string

            for bNode in baseNodes.findAll('property'):
                if uName == bNode.find('name').string:
                    bNode.find('value').string = uValue

        return baseNodes

    def xmlFileReader(self,fileName):
        f = open(fileName, 'r')
        siteXml=""
        while True:
            line = f.readline()
                    
            if not line:
                break
            siteXml+=line
        f.close()    
        return siteXml   

    def sp_open(self,command):
        popen = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        (stdoutdata, stderrdata) = popen.communicate()
        return stdoutdata, stderrdata