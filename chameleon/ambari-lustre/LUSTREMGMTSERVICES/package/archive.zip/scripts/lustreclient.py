import sys
import os
import subprocess
import ConfigParser
import time
import random
import commands
import socket
import json
from subtools import SubTools
from resource_management import *
from resource_management.core.resources.system import File, Execute, Directory
from resource_management.libraries.functions.format import format
from resource_management.core.resources.service import Service
from resource_management.core.exceptions import ComponentIsNotRunning
from resource_management.core import shell
from resource_management.libraries.script.script import Script
from ambari_agent import AmbariConfig
from resource_management.libraries.functions.default import default

class LustreClient(Script):

  def install(self, env):
    print 'install'

    import params

    print 'Install LustreMDSMgmtService.'

    # Load the all configuration files
    config = Script.get_config()
    # Bind to a local variable
    #LustreMDSMgmtService_user = config['configurations']['my-config-env']['lustremdsmgmtservice_user']
        

    # Install packages
    self.install_packages(env)
    Execute(format("yum install -y wget, libesmtp libyaml net-snmp-agent-libs opensm opensm-libs sg3_utils tcl tk"))
        

    for pkg in params.client_wget:
      download_file = 'wget '+pkg['url']
      Execute(format(download_file))

    pkg_file = 'yum install -y'
    for pkg in params.client_wget:
      pkg_file = pkg_file +' '+ pkg['name'] + ' '
        
    try:
      Execute(format(pkg_file))
    except ExecutionFailed as e:
      print(e)
      pass
        
    print 'Installation complete.'

        
    self.configure(env)

  def umount(self, env):
    print 'unmount'

  def mount(self, env):
    print 'mount'

  def status(self, env):
    print 'status'
    #raise ClientComponentHasNoStatus()

  def configure(self, env):
    print 'LustreMDSMgmtService Configure start....'
    import params

    modprobe_networks = params.modprobe_networks
    Lustrecontent = format('options lnet networks="'+modprobe_networks+'"')
    File(
      os.path.join("/etc/modprobe.d","lustre.conf"),
      owner='root',
      group='root',
      mode=0644,
      content=Lustrecontent,
    )
    Execute(format('modprobe lustre'))
        
    Directory('/lustre',
      create_parents = True,
      owner='root',
      group='root'
    )

    while True:
      (exitstatus, outtext) = commands.getstatusoutput("ssh root@"+params.mds_host+" cat /var/lib/ambari-agent/LustreOSSMgmtService_status.conf")
      if outtext == "status=1":
        break
      else:
        pass
      print("This LustreMDSMgmtService install ....")
      time.sleep(60)   # Delay for 1 minute (60 seconds).

    Execute(format('mount -t lustre  '+params.mds_host+'@'+params.network_device+':/'+params.mdt_fsname+'  /lustre'))
    print 'Configure complete.'
 
if __name__ == "__main__":
  LustreClient().execute()