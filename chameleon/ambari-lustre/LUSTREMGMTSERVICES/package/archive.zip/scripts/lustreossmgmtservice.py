import sys
import os
import subprocess
import ConfigParser
import time
import random
import commands
import socket
import json
from subtools import SubTools
from resource_management import *
from resource_management.core.resources.system import File, Execute, Directory
from resource_management.libraries.functions.format import format
from resource_management.core.resources.service import Service
from resource_management.core.exceptions import ComponentIsNotRunning
from resource_management.core import shell
from resource_management.libraries.script.script import Script
from ambari_agent import AmbariConfig
from resource_management.libraries.functions.default import default



class LustreOSSMgmtService(Script):
    def __init__(self):
        self.sbtls = SubTools()
    def install(self, env):
        import params
        print 'Install LustreOSSMgmtService.'


        subprocess.call('ssh root@'+params.mds_host+' echo "status=0" > /var/lib/ambari-agent/LustreOSSMgmtService_status.conf', shell=True)

        


        # Install packages
        self.install_packages(env)
        Execute(format("yum install -y wget, libesmtp libyaml net-snmp-agent-libs opensm opensm-libs sg3_utils tcl tk"))
        

        for pkg in params.mds_wget:
    	    download_file = 'wget '+pkg['url']
            Execute(format(download_file))

        pkg_file = 'yum install -y'
        for pkg in params.mds_wget:
            pkg_file = pkg_file +' '+ pkg['name'] + ' '
        
        try:
            Execute(format(pkg_file))
        except ExecutionFailed as e:
            print(e)
            pass
        
        print 'Installation complete.'

        
        self.configure(env)

        

    def stop(self, env):
        print 'Stop LustreOSSMgmtService'
        # Stop your service

        #Since we have not installed a real service, there is no PID file created by it.
        #Therefore we are going to artificially remove the PID.
        # Execute( "rm -f /tmp/LustreOSSMgmtService.pid" )
        self.sbtls.sp_open('python /var/lib/ambari-agent/cache/stacks/HDP/2.4/services/LUSTREMGMTSERVICES/package/scripts/daemon-lustre-oss.py stop')

    def start(self, env):
        print 'Start LustreOSSMgmtService'
        # Reconfigure all files
        # Start your service

        #Since we have not installed a real service, there is no PID file created by it.
        #Therefore we are going to artificially create the PID.
        # Execute( "touch /tmp/LustreOSSMgmtService.pid" )
        self.sbtls.sp_open('python /var/lib/ambari-agent/cache/stacks/HDP/2.4/services/LUSTREMGMTSERVICES/package/scripts/daemon-lustre-oss.py start')

    def status(self, env):
        print 'Status of LustreOSSMgmtService'
        # LustreOSSMgmtService_pid_file = "/tmp/LustreOSSMgmtService.pid"
        #check_process_status(dummy_slave_pid_file)
        # Execute( format("cat {LustreOSSMgmtService_pid_file}") )
        # pass
        check = self.sbtls.sp_open('python /var/lib/ambari-agent/cache/stacks/LUSTREMGMTSERVICES/0.1.0/package/scripts/daemon-lustre-oss.py status')
        print check
        if 'not' in str(check):
            raise ComponentIsNotRunning
        pass

    def mountosts(self, env):
        self.sbtls.excuteDaemon('sample02',5681)
        print("mountosts!!")

    def unmountosts(self, env):
        self.sbtls.excuteDaemon('sample02',5681)
        print("unmountosts!!")

    def mkfsmdts(self, env):
        self.sbtls.excuteDaemon('sample02',5681)
        print("mkfsosts!!")

    def configure(self, env):
        print 'LustreOSSMgmtService Configure start....'
        import params

        modprobe_networks = params.modprobe_networks
        Lustrecontent = format('options lnet networks="'+modprobe_networks+'"')
        File(
            os.path.join("/etc/modprobe.d","lustre.conf"),
            owner='root',
            group='root',
            mode=0644,
            content=Lustrecontent,
        )
        Execute(format('modprobe lustre'))
        Execute(format('modprobe ost'))

        while True:
            (exitstatus, outtext) = commands.getstatusoutput("ssh root@"+params.mds_host+" cat /var/lib/ambari-agent/LustreMDSMgmtService_status.conf")
            if outtext == "status=1":
                break
            else:
                pass
            print("This LustreMDSMgmtService install ....")
            time.sleep(60)   # Delay for 1 minute (60 seconds).
        
        index = 0
        for host in params.oss_hosts_list:
            if(host == params.local_hostname):
                break
            else:
                index = index + 1
                pass

        Execute(format('mkfs.lustre --fsname='+params.mdt_fsname+'  --ost --mgsnode='+params.mds_host+'@'+params.network_device+' --index='+index+' --reformat '+params.mdt_verbos))
        
        Directory('/lustre/oss'+params.mdt_index,
            create_parents = True,
            owner='root',
            group='root'
        )        
        Execute(format('mount -t lustre '+params.mdt_verbos+' /lustre/oss'+params.mdt_index))
        
        subprocess.call('ssh root@'+params.mds_host+' echo "status=1" > /var/lib/ambari-agent/LustreOSSMgmtService_status.conf', shell=True)
        
        print 'Configure complete.'
   

if __name__ == "__main__":
    LustreOSSMgmtService().execute()
