#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import re
import requests 
import json
import time
import socket
import random
import ConfigParser
import subprocess
import os
import logging
import logging.handlers

from daemon_producer_oss import Daemon

# Ambari server url
ambari_url = "cn7"
# Ambari Metrics Collect url
amc_hostname = "cn9"
#local hostname
local_hostname = ""

count = 0
logger = None

class MyDaemon(Daemon):
  def run(self):
    global logger;
    oss_producer = OssProducer();
    oss_producer.init()
    oss_producer.getOssIndex()
    while True:
      try:
        line = subprocess.check_output(format("lctl get_param obdfilter.*.stats") , shell=True)
        data = oss_producer.parse(line)
        oss_producer.produce(data)
        pass
      except Exception as e:
        logger.error(e)
        pass
      
      time.sleep(1)

class OssProducer:

  def parse(self,data):

    read_bytes_count = 0;
    read_bytes_total = 0;
    write_bytes_count = 0;
    write_bytes_total = 0;
    read_bytes_avg = 0;
    write_bytes_avg = 0;

    # print data
    ost_info = {}
    ost_status = '';
    for obdfilter in data.split('obdfilter'):
      for line in obdfilter.split('\n'):
        if(len(line.split()) > 0 and len(line.split()) < 3 ):
          ost_status = line.split('-')[1].split('.')[0]
          ost_info[ost_status] = {}
          # print ost_status
        elif(len(line.split()) > 0 and len(line.split()) > 3 ):
          # print line.split()
          if line.split()[0] in 'read_bytes':
            ost_info[ost_status]['read_bytes'] = line.split()[6]
            read_bytes_count = read_bytes_count + 1;
            read_bytes_total = read_bytes_total + int(ost_info[ost_status]['read_bytes'])
          elif line.split()[0] in 'write_bytes':
            ost_info[ost_status]['write_bytes'] = line.split()[6]
            write_bytes_count = write_bytes_count + 1;
            write_bytes_total = write_bytes_total + int(ost_info[ost_status]['write_bytes'])
          elif line.split()[0] in 'setattr':
            ost_info[ost_status]['setattr'] = line.split()[1]
          elif line.split()[0] in 'sync':
            ost_info[ost_status]['sync'] = line.split()[1]
          elif line.split()[0] in 'destroy':
            ost_info[ost_status]['destroy'] = line.split()[1]
          elif line.split()[0] in 'create':
            ost_info[ost_status]['create'] = line.split()[1]
          elif line.split()[0] in 'statfs':
            ost_info[ost_status]['statfs'] = line.split()[1]
          elif line.split()[0] in 'get_info':
            ost_info[ost_status]['get_info'] = line.split()[1]
          elif line.split()[0] in 'connect':
            ost_info[ost_status]['connect'] = line.split()[1]
          elif line.split()[0] in 'statfs':
            ost_info[ost_status]['statfs'] = line.split()[1]
          elif line.split()[0] in 'preprw':
            ost_info[ost_status]['preprw'] = line.split()[1]
          elif line.split()[0] in 'commitrw':
            ost_info[ost_status]['commitrw'] = line.split()[1]
          elif line.split()[0] in 'ping':
            ost_info[ost_status]['ping'] = line.split()[1]



    if read_bytes_count > 0 and read_bytes_count > 0:
      read_bytes_avg = read_bytes_total / read_bytes_count;
      write_bytes_avg = write_bytes_total / write_bytes_count
    else :
      read_bytes_avg = 0;
      write_bytes_avg = 0;
    # print ost_info;




    #print data
    # lines = data.split("\n");
    # obdfilters = data.split('obdfilter');


    
    # for line in lines:
    #   words = line.split();
    #   # print words
    #   if len(words) > 0:
    #     if words[0] in 'open':
    #       Open = words[1];
    #     elif words[0] in 'close':
    #       Close = words[1];
    #     elif words[0] in 'mkdir':
    #       Mkdir = words[1];
    #     elif words[0] in 'getattr':
    #       Getattr = words[1];
    #     elif words[0] in 'setattr':
    #       Setattr = words[1];
    #     elif words[0] in 'statfs':
    #       Statfs = words[1];
    #   else:
    #     continue

    # print line

    #Ost             KBRead   Reads  SizeKB    KBWrite  Writes  SizeKB
    # data = re.split(' +', line)
  #  print data

  # obdfilter.mylustre-OST0001.stats=
  # snapshot_time             1522292305.872345175 secs.nsecs
  # read_bytes                107 samples [bytes] 4096 4194304 424964096
  # write_bytes               801 samples [bytes] 1 4194304 387832897
  # setattr                   1106 samples [reqs]
  # sync                      185 samples [reqs]
  # destroy                   200 samples [reqs]
  # create                    25 samples [reqs]
  # statfs                    26300 samples [reqs]
  # get_info                  1 samples [reqs]
  # connect                   3 samples [reqs]
  # statfs                    3 samples [reqs]
  # preprw                    908 samples [reqs]
  # commitrw                  908 samples [reqs]
  # ping                      2 samples [reqs]

    # try:
    #   (open,close,mkdir,getattr,setattr,statfs) = data
    # except:
    #   open = None
    #   close = None
    #   mkdir = None
    #   getattr = None
    #   setattr = None
    #   statfs = None
      

    return (read_bytes_avg,write_bytes_avg)


  def produce(self,data):

    (read_bytes_avg,write_bytes_avg) = data

    curtime = int(round(time.time() * 1000))
  #  local_hostname ="cn7"
    
    index = str(oss_index);

    payload = {
     "metrics": [{
       "metricname": "Oss"+index+"Read",
       "appid": "lustremanager",
       "hostname": local_hostname,
       "timestamp": curtime,
       "starttime": curtime,
       "metrics": { curtime: read_bytes_avg }
     },{
       "metricname": "Oss"+index+"Write",
       "appid": "lustremanager",
       "hostname": local_hostname,
       "timestamp": curtime,
       "starttime": curtime,
       "metrics": { curtime: write_bytes_avg }
     }]
      }

    headers = {'content-type': 'application/json'}
    url = "http://" + amc_hostname + ":6188/ws/v1/timeline/metrics"

    result = json.dumps(payload)
    print str
    r = requests.post(url, data=result, headers=headers)
    print r
    print r.text

  def init(self):

    global local_hostname
    local_hostname = socket.gethostname()
    print "Local Hostname : " + local_hostname

  # ambari server hostname
    config = ConfigParser.ConfigParser()
    config.read("/etc/ambari-agent/conf/ambari-agent.ini")
    global ambari_url
    ambari_url = config.get('server','hostname')
    print "Ambari server Hostname : " + ambari_url
  # 

  # cluster_name
    headers = {
      'X-Requested-By': 'ambari',
    }
    r = requests.get('http://'+ambari_url+':8080/api/v1/clusters', headers=headers, auth=('admin', 'admin'))
    j = json.loads(r.text)
    items = j["items"][0]["Clusters"]
    global cluster_name
    cluster_name = items["cluster_name"]
    print "Cluster Name : " + items["cluster_name"]
  # 

  # Ambari Metrics Collector hostname
    r = requests.get('http://'+ambari_url+':8080/api/v1/clusters/'+items["cluster_name"]+'/services/AMBARI_METRICS/components/METRICS_COLLECTOR', headers=headers, auth=('admin', 'admin'))
    j = json.loads(r.text)
    global amc_hostname
    amc_hostname = j["host_components"][0]["HostRoles"]["host_name"]
    print "Ambari Metrics Collector Hostname : " + amc_hostname
  #


  # def getOssIndex():
  #   headers = {
  #     'X-Requested-By': 'ambari',
  #   }
  #   global oss_index
  #   global local_hostname
  #   local_hostname = socket.gethostname()
  #   # lustrefs-config-env 의 최근버전 추출
  #   r = requests.get('http://'+ambari_url+':8080/api/v1/clusters/'+cluster_name+'?fields=Clusters/desired_configs', headers=headers, auth=('admin', 'admin'))
  #   j = json.loads(r.text)
  #   lustrefs_config_env_tag = j['Clusters']['desired_configs']["lustrefs-config-env"]["tag"];
  #   # lustrefs-config-env 의 환경설정내용 추출
  #   r = requests.get('http://'+ambari_url+':8080/api/v1/clusters/'+cluster_name+'/configurations?type=lustrefs-config-env&tag='+lustrefs_config_env_tag, headers=headers, auth=('admin', 'admin'));
  #   j = json.loads(r.text)
  #   global lustrefs_config_env
  #   lustrefs_config_env =  j["items"][0]["properties"];
  #   oss_host_list = lustrefs_config_env['oss_host'].split('\n')

  #   index = 0;
  #   for idx, val in enumerate(oss_host_list):
  #     if(val.split('|')[0] in local_hostname):
  #       index = idx + 1;
  #       break
  #   global oss_index
  #   oss_index = index;
  #   print 'OSS NAME : ' + 'Oss' + str(oss_index)

  def getOssIndex(self):
    headers = {
      'X-Requested-By': 'ambari',
    }
    global oss_index
    global local_hostname
    local_hostname = socket.gethostname()
    # lustre manager 의 내용 추출
    instance_name = 'Lustre_View'
    version_name = '1.0.0'

    r = requests.get('http://'+ambari_url+':8080/views/Lustre_View/'+version_name+'/'+instance_name+'/api/v1/ambari/getLustreNodes', headers=headers, auth=('admin', 'admin'))
    nodes = json.loads(r.text)
    for node in nodes:
      if node['host_name'] == local_hostname:
        oss_index = node['index'] + 1;
        print 'OSS NAME : ' + 'Oss' + str(oss_index)
        break;
        pass
      pass

    

    pass;



# init()
# getOssIndex()
# while 1:
#   try:
#       time.sleep(1)
#       line = subprocess.check_output(format("lctl get_param obdfilter.*.stats") , shell=True)
#       # line = '';
#       # line = sys.stdin.readline()
#   except KeyboardInterrupt:
#       break

#   # if not line:
#   #    break
#   #print line
#   data = parse(line)
#   # parse(line)
#   #print data

#   produce(data)
#   # produce()

if __name__ == "__main__":

  file_path = os.path.dirname(os.path.realpath(__file__));
  logger = logging.getLogger('mylogger')
  fileMaxByte = 1024 * 1024 * 100 #100MB
  log_file_name = file_path+'/oss_producer.log';
  filehander = logging.handlers.RotatingFileHandler(log_file_name, maxBytes=fileMaxByte, backupCount=10)
  streamHandler = logging.StreamHandler()  
  fomatter = logging.Formatter('[%(levelname)s|%(filename)s:%(lineno)s] %(asctime)s > %(message)s')
  filehander.setFormatter(fomatter)
  logger.addHandler(filehander)

  daemon = MyDaemon('/tmp/daemon-oss-producer.pid')
  if len(sys.argv) == 2:
    if 'start' == sys.argv[1]:
      daemon.start()
    elif 'stop' == sys.argv[1]:
      daemon.stop()
    elif 'restart' == sys.argv[1]:
      daemon.restart()
    else:
      print "Unknown command"
      sys.exit(2)
      sys.exit(0)
  else:
    print "usage: %s start|stop|restart" % sys.argv[0]
    sys.exit(2)
